﻿using System;
using System.Collections.Generic;

namespace _1988106
{
    struct LoaiHang
    {
        public string TenLoai;
    }
    class XL_LoaiHang
    {
        public static void XuatLoaiHang(List<LoaiHang> B)
        {
            if (B.Count > 0)
            {
                Console.Write("Loai hang: ");
                for (int i = 0; i < B.Count; i++)
                {
                    Console.Write($"{i}. {B[i].TenLoai} \t");
                }
                Console.WriteLine();
                Console.WriteLine("=================");
            }
        }

        public static void ThemLoaiHang(List<LoaiHang> B)
        {
            LoaiHang them;
            Console.Write("Nhap ten loai hang: ");
            them.TenLoai = Console.ReadLine();
            B.Add(them);
        }

        public static void XoaLoaiHang(List<SanPham> A, List<LoaiHang> B)
        {
            if (B.Count != 0)
            {
                Console.Write("Vi tri loai hang can xoa: ");
                int i = XL_Menu.NhapSo();
                LoaiHang n = B[i];
                bool coXoa = true;
                for (int j = 0; j < A.Count; j++)
                {
                    if (n.TenLoai == A[j].LoaiSP)
                    {
                        coXoa = false;
                        Console.WriteLine("Vui long xoa san pham !");
                        Console.ReadLine();
                        break;
                    }
                }
                if (coXoa) B.Remove(B[i]);
            }
            else
            {
                Console.WriteLine("Vui long nhap loai hang !");
                Console.ReadLine();
            }
        }

        public static void SuaLoaiHang(List<SanPham> A, List<LoaiHang> B)
        {
            if (B.Count > 0)
            {
                Console.Write("Vi tri loai hang can sua: ");
                int i = XL_Menu.NhapSo();
                if (i <= B.Count)
                {
                    LoaiHang n = B[i];
                    Console.Write($"LoaiSP: {n.TenLoai} => ");
                    string m = Console.ReadLine();
                    // Cập nhật loại hàng bên sản phẩm trước
                    for (int j = 0; j < A.Count; j++)
                    {
                        if (n.TenLoai == A[j].LoaiSP)
                        {
                            SanPham s = A[j];
                            s.LoaiSP = m;
                            A[j] = s;
                        }
                    }
                    // Sau đó mới cập nhật loại hàng
                    n.TenLoai = m;
                    B[i] = n;
                }
                else
                {
                    Console.WriteLine("So nhap khong hop le !");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Vui long nhap loai hang !");
                Console.ReadLine();
            }
        }

        public static void TimLoaiHang(List<LoaiHang> B)
        {
            if (B.Count != 0)
            {
                Console.Write("Nhap ten loai hang can tim: ");
                string tim = Console.ReadLine();
                bool coTim = false;
                for (int i = 0; i < B.Count; i++)
                {
                    if (tim == B[i].TenLoai)
                    {
                        Console.WriteLine("Tim thay " + tim);
                        coTim = true;
                        break;
                    }
                }
                if (!coTim) Console.WriteLine("Khong tim thay !");
                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("Vui long nhap loai hang !");
                Console.ReadLine();
            }
        }
    }
}
