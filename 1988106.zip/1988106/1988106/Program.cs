﻿using System;
using System.Collections.Generic;

namespace _1988106
{
    class Program
    {
        static void Main(string[] args)
        {
            List<SanPham> A = new List<SanPham>();
            List<LoaiHang> B = new List<LoaiHang>();
            XL_Menu.XuatMenu(A, B);
            Console.ReadLine();
        }
    }
}
