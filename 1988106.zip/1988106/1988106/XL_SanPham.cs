﻿using System;
using System.Collections.Generic;

namespace _1988106
{
    struct SanPham
    {
        public int MaSP;
        public string TenSP;
        public int HanSD;
        public string NhaSX;
        public int NamSX;
        public string LoaiSP;
    }
    class XL_SanPham
    {
        static SanPham NhapSanPham(List<LoaiHang> B)
        {
            SanPham A;
            Console.Write("Ma san pham: ");
            A.MaSP = XL_Menu.NhapSo();
            Console.Write("Ten san pham: ");
            A.TenSP = Console.ReadLine();
            Console.Write("Chon stt loai hang: ");
            int i = XL_Menu.NhapSo();
            A.LoaiSP = B[i].TenLoai;
            Console.Write("Nha san xuat: ");
            A.NhaSX = Console.ReadLine();
            Console.Write("Nam san xuat: ");
            A.NamSX = XL_Menu.NhapSo();
            Console.Write("Nam het han: ");
            A.HanSD = XL_Menu.NhapSo();
            return A;
        }
        
        public static void XuatDonHang(List<SanPham> A)
        {
            if (A.Count > 0)
            {
                Console.WriteLine("STT \t TenSP \t\t MaSP \t Loai \t\t NhaSX \t\t NamSX \t HanSD");
                for (int i = 0; i < A.Count; i++)
                {
                    Console.WriteLine($"{i} \t {A[i].TenSP} \t {A[i].MaSP} \t {A[i].LoaiSP} \t {A[i].NhaSX} \t {A[i].NamSX} \t {A[i].HanSD}");
                }
            }
        }

        public static void ThemSanPham(List<SanPham> A, List<LoaiHang> B)
        {
            SanPham them;
            if (B.Count != 0)
            {
                them = NhapSanPham(B);
                A.Add(them);
            }
            else
            {
                Console.WriteLine("Vui long nhap loai hang !");
                Console.ReadLine();
            }
        }

        public static void XoaSanPham(List<SanPham> A)
        {
            if (A.Count != 0)
            {
                Console.Write("Vi tri san pham can xoa: ");
                int n = XL_Menu.NhapSo();
                if (n <= A.Count) A.Remove(A[n]);
                else
                {
                    Console.WriteLine("So nhap khong hop le !");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Vui long nhap san pham !");
                Console.ReadLine();
            }
        }

        public static void SuaDonHang(List<SanPham> A, List<LoaiHang> B)
        {
            if (A.Count != 0)
            {
                Console.Write("Vi tri san pham can sua: ");
                int i = XL_Menu.NhapSo();
                if (i <= A.Count)
                {
                    SanPham n = A[i];
                    Console.Write($"MaSP: {n.MaSP} => ");
                    n.MaSP = XL_Menu.NhapSo();
                    Console.Write($"TenSP: {n.TenSP} => ");
                    n.TenSP = Console.ReadLine();
                    Console.Write($"NhaSX: {n.NhaSX} => ");
                    n.NhaSX = Console.ReadLine();
                    Console.Write($"NamSX: {n.NamSX} => ");
                    n.NamSX = XL_Menu.NhapSo();
                    Console.Write($"HanSD: {n.HanSD} => ");
                    n.HanSD = XL_Menu.NhapSo();
                    A[i] = n;
                } 
                else
                {
                    Console.WriteLine("So nhap khong hop le !");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Vui long nhap san pham !");
                Console.ReadLine();
            }
        }

        public static void TimSanPham(List<SanPham> A)
        {
            if (A.Count != 0)
            {
                Console.Write("Nhap ten san pham can tim: ");
                string tim = Console.ReadLine();
                bool coTim = false;
                for (int i = 0; i < A.Count; i++)
                {
                    if (A[i].TenSP == tim)
                    {
                        Console.WriteLine("Tim thay " + tim);
                        coTim = true;
                        Console.ReadLine();
                        break;
                    }
                }
                if (!coTim)
                {
                    Console.WriteLine("Khong tim thay !");
                    Console.ReadLine();
                }
            }
            else
            {
                Console.WriteLine("Vui long nhap san pham !");
                Console.ReadLine();
            }
        }
    }
}
