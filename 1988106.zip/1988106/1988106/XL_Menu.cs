﻿using System;
using System.Collections.Generic;

namespace _1988106
{
    class XL_Menu
    {
        public static int NhapSo()
        {
            int n;
            int.TryParse(Console.ReadLine(), out n);
            return n;
        }
        static int NhapMenu(List<SanPham> A, List<LoaiHang> B)
        {
            int n;
            do
            {
                Console.Clear();
                Console.WriteLine("      MENU");
                Console.WriteLine("1. Them loai hang");
                Console.WriteLine("2. Xoa loai hang");
                Console.WriteLine("3. Sua loai hang");
                Console.WriteLine("4. Tim loai hang");
                Console.WriteLine("5. Them san pham");
                Console.WriteLine("6. Xoa san pham");
                Console.WriteLine("7. Sua san pham");
                Console.WriteLine("8. Tim san pham");
                Console.WriteLine("9. Thoat ung dung");
                Console.WriteLine("=================");
                XL_SanPham.XuatDonHang(A);
                XL_LoaiHang.XuatLoaiHang(B);
                Console.Write("Chon thao tac: ");
                n = NhapSo();
            } while (n > 9);
            return n;
        }
        public static void XuatMenu(List<SanPham> A, List<LoaiHang> B)
        {
            bool Tiep = true;
            do
            {
                int n = NhapMenu(A, B);
                switch (n)
                {
                    case 1: XL_LoaiHang.ThemLoaiHang(B); break;
                    case 2: XL_LoaiHang.XoaLoaiHang(A, B); break;
                    case 3: XL_LoaiHang.SuaLoaiHang(A, B); break;
                    case 4: XL_LoaiHang.TimLoaiHang(B); break;
                    case 5: XL_SanPham.ThemSanPham(A, B); break;
                    case 6: XL_SanPham.XoaSanPham(A); break;
                    case 7: XL_SanPham.SuaDonHang(A, B); break;
                    case 8: XL_SanPham.TimSanPham(A); break;
                    case 9: Tiep = false; break;
                }
            } while (Tiep);
        }
    }
}